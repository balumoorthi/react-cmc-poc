import PropTypes from 'prop-types';

const DInputDefaultPropTypes = {
  fieldProps: {},
  control: {},
};

const DInputPropTypes = {
  fieldProps: PropTypes.objectOf(PropTypes.shape({})),
  control: PropTypes.objectOf(PropTypes.shape({})),
};

const DFieldLayoutDefaultPropTypes = {
  containerProps: {},
  labelProps: {},
  fieldProps: {},
  errorProps: {},
  errors: {},
  register: () => {},
};

const DFieldLayoutPropTypes = {
  containerProps: PropTypes.objectOf(PropTypes.shape({})),
  labelProps: PropTypes.objectOf(PropTypes.shape({})),
  fieldProps: PropTypes.objectOf(PropTypes.shape({})),
  errorProps: PropTypes.objectOf(PropTypes.shape({})),
  errors: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.objectOf(PropTypes.shape({})),
  ]),
  register: PropTypes.func,
};

export {
  DInputDefaultPropTypes,
  DInputPropTypes,
  DFieldLayoutDefaultPropTypes,
  DFieldLayoutPropTypes,
};
