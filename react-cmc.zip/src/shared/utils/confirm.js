import { Modal } from 'antd';

const { confirm } = Modal;

const DConfirmDialog = options => {
  confirm(options);
};

export default DConfirmDialog;
