import generateComponent from './generateComponents';

import generateColumns from './generateColumns';

export { generateComponent, generateColumns };
