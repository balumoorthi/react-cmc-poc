const generateColumns = (componentDetails, props) => {
  console.log(componentDetails, props);
};

export default generateColumns;
