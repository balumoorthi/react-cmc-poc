import React from 'react';

const OptionsTool = () => (
  <div className="options-tool">
    <div className="container-name">
      <span />
    </div>
  </div>
);

export default OptionsTool;
