import React from 'react';

import PropTypes from 'prop-types';

import { Dropdown } from 'antd';

import { useSelector, useDispatch } from 'react-redux';

import { openSidebar } from 'shared/store/reducers/app';

const DTopbar = ({ options, actionBar }) => {
  const { menu } = options;

  console.log('Dashboard Header');

  const app = useSelector(state => state.app);

  const { isSidebarOpen } = app;

  const dispatch = useDispatch();

  const toggleSidebar = () => {
    dispatch(openSidebar(!isSidebarOpen));
  };

  return (
    <div className="topbar">
      <div className="sidebar-toggler">
        <span
          role="button"
          className="toogle-sidebar"
          onClick={toggleSidebar}
          onKeyDown={toggleSidebar}
          tabIndex={0}
        >
          <i className="bi bi-text-indent-right" />
        </span>
      </div>
      <div className="action-bar-section">{actionBar}</div>
      <div className="sign-in-section">
        <div className="user-info">
          <div className="img-wrapper">
            <img src="" alt="" />
          </div>
          <Dropdown overlay={menu} placement="bottomLeft" arrow>
            <div className="info">
              <p className="name">Nrk</p>
              <p className="role">Admin</p>
            </div>
          </Dropdown>
        </div>
      </div>
    </div>
  );
};

DTopbar.propTypes = {
  options: PropTypes.objectOf(PropTypes.shape({})).isRequired,
  actionBar: PropTypes.objectOf(PropTypes.shape({})).isRequired,
};

export default DTopbar;
