const sidebarMenu = [
  {
    id: 1,
    icon: 'bi bi-house-door',
    label: 'Dashboard',
    link: '/dashboard',
  },
  {
    id: 2,
    icon: 'bi bi-file-code',
    label: 'Users',
    link: 'users',
  },
  {
    id: 3,
    icon: 'bi bi-file-code',
    label: 'Projects',
    link: 'projects',
  },
  {
    id: 4,
    icon: 'bi bi-file-code',
    label: 'Pages',
    link: 'pages',
  },
  {
    id: 5,
    icon: 'bi bi-file-code',
    label: 'Editor',
    link: 'editor',
  },
];

const subMenuIds = ['2'];

export { sidebarMenu, subMenuIds };
