const configData = process.env;

const config = {};

try {
  config.apiURL =
    configData.REACT_APP_API_BASE_URI || 'http://3.109.2.39:1337/api/';
  config.basicMailURL = '';
} catch {
  config.apiURL = 'http://3.109.2.39:1337/api/';
  config.basicMailURL = '';
}

export default config;
