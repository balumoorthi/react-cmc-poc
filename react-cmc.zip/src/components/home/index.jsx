import React from 'react';

import DashboardLayout from 'layout/DashboardLayout';

const HomePage = () => (
  <DashboardLayout>
    <h2>Dashboard section</h2>
  </DashboardLayout>
);

export default HomePage;
