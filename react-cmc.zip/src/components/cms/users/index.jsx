import React from 'react';
// import PropTypes from 'prop-types';

import UsersListing from './listing';

const Users = () => <UsersListing />;

// Users.propTypes = {};

export default Users;
