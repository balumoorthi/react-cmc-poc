import { getUsers } from 'services/cms/users';

const UserTableSchema = {
  table: {
    header: {
      title: 'Users',
    },

    columns: [
      {
        Header: 'Name',
        accessor: 'username',
      },
      {
        Header: 'Email',
        accessor: 'email',
      },
      {
        Header: 'Provider',
        accessor: 'provider',
      },
      {
        Header: 'Created On',
        accessor: 'createdAt',
        disableFilters: true,
      },
    ],
    actions: {
      edit: {},
      remove: {},
    },
  },

  service: {
    method: getUsers,
    responseFormat: {
      data: '',
    },
  },

  toolbar: {
    bulkActionIsVisible: false,
    actionBtn: {
      edit: {},
      remove: {},
    },
  },
};

export default UserTableSchema;
