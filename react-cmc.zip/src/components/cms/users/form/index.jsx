import React from 'react';

import PropTypes from 'prop-types';

import DForm from 'shared/core/form';

import { Input, Select } from 'shared/core/form/fields';

import { getProjects } from 'services/cms/projects';

import { UsersAddSchema, UsersUpdateSchema } from './schema';

const UsersForm = ({ isEdit, initValue, onSubmit }) => {
  console.log('user form');

  return (
    <DForm
      fieldProps={{ id: 'userForm', className: 'row' }}
      formProps={{
        onSubmit,
        schema: isEdit ? UsersUpdateSchema : UsersAddSchema,
        initialValues: initValue,
      }}
      containerProps={{
        className: 'col-md-6 mb-3',
        labelClassName: 'label',
      }}
    >
      <Input
        fieldProps={{ type: 'text', name: 'username' }}
        labelProps={{ name: 'User Name' }}
      />

      {!isEdit && (
        <Input
          fieldProps={{ type: 'password', name: 'password' }}
          labelProps={{ name: 'Password' }}
        />
      )}

      <Input
        fieldProps={{ type: 'email', name: 'email' }}
        labelProps={{ name: 'Email' }}
      />

      {!isEdit && (
        <Select
          fieldProps={{
            name: 'projects',
            closeMenuOnSelect: false,
          }}
          serviceProps={{
            method: getProjects,
            params: {},
            payload: {},
            label: 'attributes.project_name',
            value: 'id',
          }}
          labelProps={{ name: 'Projects' }}
        />
      )}
    </DForm>
  );
};

UsersForm.propTypes = {
  isEdit: PropTypes.bool.isRequired,
  initValue: PropTypes.objectOf(PropTypes.shape({})).isRequired,
  onSubmit: PropTypes.func.isRequired,
};

export default UsersForm;
