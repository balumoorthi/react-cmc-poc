import * as yup from 'yup';

const UsersSchema = {
  username: yup.string().required('This field required'),
  email: yup.string().email().required('This field required'),
  password: yup.string().required('This field required'),
  projects: yup.mixed(),
};

const { username, email } = UsersSchema;

const UsersAddSchema = yup.object(UsersSchema);

const UsersUpdateSchema = yup.object({ username, email });

export { UsersAddSchema, UsersUpdateSchema };
