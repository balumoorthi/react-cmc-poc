import { getpages } from 'services/cms/pages';

const PageTableSchema = {
  table: {
    header: {
      title: 'Pages',
    },

    columns: [
      {
        Header: 'Title',
        accessor: 'attributes.title',
      },
      {
        Header: 'Created On',
        accessor: 'attributes.createdAt',
        disableFilters: true,
      },
    ],
    actions: {
      edit: {},
      remove: {},
    },
  },

  service: {
    method: getpages,
    responseFormat: {
      total: 'meta.pagination.total',
    },
    params: {},
  },

  toolbar: {
    bulkActionIsVisible: false,
    actionBtn: {
      edit: {},
      remove: {},
    },
  },
};

export default PageTableSchema;
