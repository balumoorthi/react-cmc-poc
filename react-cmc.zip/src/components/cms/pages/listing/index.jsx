import React, { useMemo, useCallback } from 'react';

// import PropTypes from 'prop-types';

import DTable from 'shared/core/datatable/index';

import { confirmRemove } from 'shared/utils/response';

import { removeProject } from 'services/cms/projects';

import { useSelector } from 'react-redux';

import { useNavigate } from 'react-router-dom';

import isEmpty from 'lodash/isEmpty';

import PageTableSchema from './schema';

const PageListing = () => {
  const navigate = useNavigate();

  const appDetails = useSelector(state => state.app);

  const openAddPageModal = useCallback(() => {
    navigate(`content-editor`);
  }, []);

  const openEditPageModal = useCallback(() => {
    navigate(`content-editor`);
  }, []);

  const deletePage = useCallback(({ id }) => {
    confirmRemove(removeProject, id, {
      config: {
        toaster: {
          success: 'Project removed successfully',
          error: 'Project not removed',
        },
      },
    });
  }, []);

  const projectTable = useMemo(() => {
    PageTableSchema.toolbar.addBtnOnClick = openAddPageModal;

    PageTableSchema.table.actions.edit.onClick = openEditPageModal;

    PageTableSchema.table.actions.remove.onClick = deletePage;

    if (!isEmpty(appDetails.selectedProject)) {
      PageTableSchema.service.params = {
        'filters[project][id][$eq]': appDetails.selectedProject.value,
      };
    }

    return PageTableSchema;
  });

  return (
    <div>
      {appDetails.selectedProject.value && (
        <DTable tableConfig={projectTable} />
      )}
    </div>
  );
};

// PageListing.propTypes = {};

export default PageListing;
