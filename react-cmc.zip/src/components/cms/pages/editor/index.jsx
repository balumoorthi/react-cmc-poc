import React from 'react';

// import PropTypes from 'prop-types';

import DForm from 'shared/core/form';

import { Input } from 'shared/core/form/fields';

import PageSchema from './schema';

const PageEditor = () => {
  console.log('page editor');

  const onPageSave = data => {
    console.log(data);
  };

  return (
    <div className="page-editor">
      <DForm
        fieldProps={{ id: 'pageForm', className: 'row' }}
        formProps={{
          onPageSave,
          schema: PageSchema,
          // initialValues: initValue,
        }}
        containerProps={{
          className: 'col-md-6 mb-3',
          labelClassName: 'label',
        }}
      >
        <Input
          fieldProps={{ type: 'text', name: 'title' }}
          labelProps={{ name: 'Title' }}
        />
        <Input
          fieldProps={{ type: 'text', name: 'content' }}
          labelProps={{ name: 'content' }}
        />
      </DForm>

      <div className="button-section">
        <button className="" type="button">
          Cancel
        </button>
        <button className="" type="submit" form="pageForm">
          Save
        </button>
      </div>
    </div>
  );
};

PageEditor.propTypes = {};

export default PageEditor;
