import React from 'react';
// import PropTypes from 'prop-types';

import PageListing from './listing';

const Pages = () => <PageListing />;

// Pages.propTypes = {};

export default Pages;
