import { usersProject } from 'services/cms/projects';

const ProjectTableSchema = {
  table: {
    header: {
      title: 'Projects',
    },

    columns: [
      {
        Header: 'Project Name',
        accessor: 'attributes.project_name',
      },
      {
        Header: 'Description',
        accessor: 'attributes.description',
      },
      {
        Header: 'Created On',
        accessor: 'attributes.createdAt',
        disableFilters: true,
      },
    ],
    actions: {
      edit: {},
      remove: {},
    },
  },

  service: {
    method: usersProject,
    responseFormat: {},
  },

  toolbar: {
    bulkActionIsVisible: false,
    actionBtn: {
      edit: {},
      remove: {},
    },
  },
};

export default ProjectTableSchema;
