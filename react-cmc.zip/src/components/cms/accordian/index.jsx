import React from 'react';
// import PropTypes from 'prop-types';

import ProjectListing from './listing';

const Projects = () => <ProjectListing />;

// Projects.propTypes = {};

export default Projects;
