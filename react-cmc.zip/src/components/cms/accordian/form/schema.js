import * as yup from 'yup';

const ProjectSchema = yup.object({
  projectName: yup.string().required('This field required'),
  description: yup.string().required('This field required'),
});

export default ProjectSchema;
