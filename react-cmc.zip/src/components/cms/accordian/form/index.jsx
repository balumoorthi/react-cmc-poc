import React from 'react';

import PropTypes from 'prop-types';

import DForm from 'shared/core/form';

import { Input } from 'shared/core/form/fields';

import ProjectSchema from './schema';

const ProjectForm = ({ initValue, onSubmit }) => {
  console.log('user form');

  return (
    <DForm
      fieldProps={{ id: 'projectForm', className: 'row' }}
      formProps={{
        onSubmit,
        schema: ProjectSchema,
        initialValues: initValue,
      }}
      containerProps={{
        className: 'col-md-6 mb-3',
        labelClassName: 'label',
      }}
    >
      <Input
        fieldProps={{ type: 'text', name: 'projectName' }}
        labelProps={{ name: 'Project Name' }}
      />
      <Input
        fieldProps={{ type: 'text', name: 'description' }}
        labelProps={{ name: 'Description' }}
      />
    </DForm>
  );
};

ProjectForm.propTypes = {
  // isEdit: PropTypes.bool.isRequired,
  initValue: PropTypes.objectOf(PropTypes.shape({})).isRequired,
  onSubmit: PropTypes.func.isRequired,
};

export default ProjectForm;
