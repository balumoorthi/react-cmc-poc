import React, { useState, useMemo, useCallback } from 'react';

// import PropTypes from 'prop-types';

import DTable from 'shared/core/datatable/index';

import DModal from 'shared/antd/modal';

import modalPopup from 'shared/utils/modal';

import { confirmRemove, addItem } from 'shared/utils/response';

import { addProject, removeProject } from 'services/cms/projects';

import ProjectForm from '../form';

import ProjectTableSchema from './schema';

const ProjectListing = () => {
  const [isEdit, setIsEdit] = useState(false);

  const [projectFormInitValue, setProjectFormInitValue] = useState({});

  const openAddProjectModal = useCallback(() => {
    setIsEdit(false);
    setProjectFormInitValue({});
    modalPopup.custom({ title: 'Add Project', visible: true });
  }, []);

  const openEditProjectModal = useCallback(({ projectName, description }) => {
    setIsEdit(true);
    setProjectFormInitValue({ projectName, description });
    modalPopup.custom({ title: 'Edit Project', visible: true });
  }, []);

  const createProject = useCallback(data => {
    const projectRes = addItem({
      method: addProject,
      payload: data,
      toaster: {
        success: 'Project added successfully',
        error: 'Project not added',
      },
    });

    console.log(projectRes);
  }, []);

  const modifyProject = useCallback(data => {
    console.log(data);
  }, []);

  const deleteProject = useCallback(({ id }) => {
    confirmRemove(removeProject, id, {
      config: {
        toaster: {
          success: 'Project removed successfully',
          error: 'Project not removed',
        },
      },
    });
  }, []);

  const projectTable = useMemo(() => {
    ProjectTableSchema.toolbar.addBtnOnClick = openAddProjectModal;

    ProjectTableSchema.table.actions.edit.onClick = openEditProjectModal;

    ProjectTableSchema.table.actions.remove.onClick = deleteProject;

    ProjectTableSchema.service.params = {
      'filters[user][id][$eq]': 8,
    };

    return ProjectTableSchema;
  });

  return (
    <>
      <DTable tableConfig={projectTable} />
      <DModal options={{ formName: 'projectForm' }}>
        <ProjectForm
          isEdit={isEdit}
          initValue={projectFormInitValue}
          onSubmit={isEdit ? modifyProject : createProject}
        />
      </DModal>
    </>
  );
};

// ProjectListing.propTypes = {};

export default ProjectListing;
