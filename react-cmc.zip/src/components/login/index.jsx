import React, { useCallback, useEffect } from 'react';

import {
  HfnFirebaseAuth,
  signOut,
} from '@heartfulnessinstitute/react-hfn-profile';

import { useNavigate } from 'react-router-dom';

import { authLogin } from 'services/cms/users';

import { lStorage } from 'utils/storage';

import { isLoginAuth } from 'utils/login';

import { toast } from 'react-toastify';

const Login = () => {
  const navigate = useNavigate();

  const loggedIn = useCallback(async ({ myInfo }) => {
    try {
      if (myInfo.id) {
        const loginData = {
          identifier: myInfo.email,
          password: 'admin@123',
        };

        const logRes = await authLogin(loginData);

        if (logRes && logRes.data) {
          lStorage.set('token', logRes.data.jwt);
          lStorage.set('user', logRes.data.user);
          navigate('/dashboard');
          toast.success('Login successfully');
        } else {
          toast.error('Somthing went wrong');
        }
      }
    } catch (err) {
      console.log(err);
    }
  }, []);

  useEffect(() => {
    if (isLoginAuth()) {
      navigate('/dashboard');
    } else {
      signOut();
    }
  }, []);

  return (
    <div>
      <HfnFirebaseAuth doLogin={loggedIn} />
    </div>
  );
};

export default Login;
