import React from 'react';

import Select from 'react-select';

import { useSelector } from 'react-redux';

import isArray from 'lodash/isArray';

import appDetails from 'shared/utils/app';

const Topbar = () => {
  const projectOptions = useSelector(state => state.dropdowns);

  let selectedProject = {};

  const customStyles = {
    container: provided => ({
      ...provided,
      width: '100%',
    }),
    singleValue: provided => ({
      ...provided,
      overflow: 'initial',
    }),
    option: provided => ({
      ...provided,
      padding: '15px',
    }),
  };

  if (isArray(projectOptions?.userProjects)) {
    selectedProject = projectOptions?.userProjects[0];
    appDetails.project(selectedProject);
  }

  const setProjectName = ev => {
    appDetails.project(ev);
  };

  return (
    <div className="project-select-wrapper">
      {projectOptions?.userProjects && (
        <>
          <span>Project : </span>
          <div className="project-select">
            <Select
              defaultValue={selectedProject}
              styles={customStyles}
              options={projectOptions?.userProjects}
              onChange={setProjectName}
            />
          </div>
        </>
      )}
    </div>
  );
};

Topbar.propTypes = {};

export default Topbar;
