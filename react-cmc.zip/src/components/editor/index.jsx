import React from 'react';

import DEditor from 'shared/antd/editor';

const Editor = () => {
  console.log('editor');
  return <DEditor />;
};

export default Editor;
