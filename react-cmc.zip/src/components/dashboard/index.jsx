import React from 'react';
// import PropTypes from 'prop-types';

const Dashboard = () => <h3>dashboard section</h3>;

// Index.propTypes = {};

export default Dashboard;
