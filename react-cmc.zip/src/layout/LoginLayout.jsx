import React from 'react';

import { Outlet } from 'react-router-dom';

const LoginLayout = () => <Outlet />;

export default LoginLayout;
