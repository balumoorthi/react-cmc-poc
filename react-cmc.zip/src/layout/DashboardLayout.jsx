import React from 'react';

import { Menu } from 'antd';

import { Link } from 'react-router-dom';

import Topbar from 'components/topbar/';

import DBoard from 'shared/antd/dashboard/';

import { sidebarMenu, subMenuIds } from 'assets/data/sidebar';

const DashboardLayout = () => {
  const infoMenu = (
    <Menu>
      <Menu.Item>
        <Link to="settings">
          <i className="bi bi-gear" />
          <span>Settings</span>
        </Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="settings">
          <i className="bi bi-box-arrow-right" />
          <span>Logout</span>
        </Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <DBoard
      sidebarOptions={{
        data: sidebarMenu,
        subMenuId: subMenuIds,
        multiple: true,
      }}
      actionBar={<Topbar />}
      topbarOptions={{
        menu: infoMenu,
      }}
    />
  );
};

export default DashboardLayout;
