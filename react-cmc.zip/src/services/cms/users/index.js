import ax from '../../index';

const UserService = {
  authLogin: payload => {
    ax.post(`auth/local`, payload);
  },

  getUser: userId => ax.get(`users/${userId}`),

  getUsers: () => ax.get(`users`),

  addUsers: payload => ax.post(`users`, payload),

  updateUsers: payload => ax.put(`users`, payload),

  removeUsers: userId => ax.delete(`users/${userId}`),
};

export const {
  authLogin,
  getUser,
  getUsers,
  addUsers,
  updateUsers,
  removeUsers,
} = UserService;
