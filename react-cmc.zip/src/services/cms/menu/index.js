import ax from '../../index';

const menuService = {
  getMenu: params => ax.get(`menus`, { params }),

  // getMenus: params => ax.get(`menus/`, { params }),

  addMenu: payload => ax.post(`menus`, payload),

  updateMenu: (payload, menuId) => ax.put(`menus/${menuId}`, payload),

  removeMenu: menuId => ax.delete(`menus/${menuId}`),
};

export const { getMenu, addMenu, updateMenu, removeMenu } = menuService;
