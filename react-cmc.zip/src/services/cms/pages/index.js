import ax from '../../index';

const pageService = {
  getpage: (pageId, params) => ax.get(`pages/${pageId}`, { params }),

  getpages: params => ax.get(`pages`, { params }),

  addpage: payload => ax.post(`pages`, payload),

  updatepage: payload => ax.put(`pages`, payload),

  removepage: pageId => ax.delete(`pages/${pageId}`),
};

export const { getpage, getpages, addpage, updatepage, removepage } =
  pageService;
