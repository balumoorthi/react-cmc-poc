import ax from '../../index';

const ProjectService = {
  getProject: projectId => ax.get(`projects/${projectId}`),

  getProjects: () => ax.get(`projects`),

  addProject: payload => ax.post(`projects`, payload),

  updateProject: payload => ax.put(`projects`, payload),

  removeProject: projectId => ax.delete(`projects/${projectId}`),

  usersProject: params => ax.get(`projects`, { params }),
};

export const {
  getProject,
  getProjects,
  addProject,
  updateProject,
  removeProject,
  usersProject,
} = ProjectService;
