import { lStorage } from '../utils/storage';

const interceptor = ax => {
  ax.interceptors.request.use(
    config => {
      const token = lStorage.get('authInfo')
        ? lStorage.get('authInfo').token
        : null;

      const HeaderConfig = config;

      HeaderConfig.headers = {
        Authorization: `Bearer ${token}`,
      };
      return HeaderConfig;
    },

    error => {
      Promise.reject(error);
    }
  );
};

export default interceptor;
